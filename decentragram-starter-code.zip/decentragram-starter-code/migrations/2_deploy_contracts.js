const Decentragram = artifacts.require("Decentragram");

module.exports = function(deployer) {
  // Code goes here...
};